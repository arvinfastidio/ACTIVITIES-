function toggleLight() {
    const image = document.getElementById('myImage');
    const button = document.getElementById('toggleButton');

    if (image.src.includes('bulboff.gif')) {
        image.src = 'bulbon.gif';
        button.textContent = 'Turn Off';
    } else {
        image.src = 'bulboff.gif';
        button.textContent = 'Turn On';
    }
}